const giftedtech_0x14efe8 = giftedtech_0x5e74;
(function (_0x471ee8, _0x2524a4) {
    const _0x1f9a9b = giftedtech_0x5e74, _0x1394a2 = _0x471ee8();
    while (!![]) {
        try {
            const _0x33a162 = -parseInt(_0x1f9a9b(0x18b)) / 0x1 * (parseInt(_0x1f9a9b(0x17c)) / 0x2) + parseInt(_0x1f9a9b(0x189)) / 0x3 + -parseInt(_0x1f9a9b(0x18f)) / 0x4 * (-parseInt(_0x1f9a9b(0x188)) / 0x5) + -parseInt(_0x1f9a9b(0x182)) / 0x6 + -parseInt(_0x1f9a9b(0x18e)) / 0x7 + parseInt(_0x1f9a9b(0x180)) / 0x8 + -parseInt(_0x1f9a9b(0x179)) / 0x9 * (-parseInt(_0x1f9a9b(0x17d)) / 0xa);
            if (_0x33a162 === _0x2524a4)
                break;
            else
                _0x1394a2['push'](_0x1394a2['shift']());
        } catch (_0x4350af) {
            _0x1394a2['push'](_0x1394a2['shift']());
        }
    }
}(giftedtech_0x3bab, 0xaf070));
function giftedtech_0x5e74(_0x571f97, _0x3221d8) {
    const _0x3bab51 = giftedtech_0x3bab();
    return giftedtech_0x5e74 = function (_0x5e74f9, _0x5eab6d) {
        _0x5e74f9 = _0x5e74f9 - 0x179;
        let _0x3e5ce6 = _0x3bab51[_0x5e74f9];
        return _0x3e5ce6;
    }, giftedtech_0x5e74(_0x571f97, _0x3221d8);
}
const FormData = require(giftedtech_0x14efe8(0x184));
async function remini(_0x19d377, _0x45d309) {
    return new Promise(async (_0x42ad59, _0x528f23) => {
        const _0x417e90 = giftedtech_0x5e74;
        let _0x2dfb23 = [
            _0x417e90(0x187),
            _0x417e90(0x190),
            _0x417e90(0x193)
        ];
        _0x2dfb23[_0x417e90(0x18a)](_0x45d309) ? _0x45d309 = _0x45d309 : _0x45d309 = _0x2dfb23[0x0];
        let _0x33085c = new FormData(), _0x3d731a = _0x417e90(0x181) + _0x45d309;
        _0x33085c[_0x417e90(0x17b)]('model_version', 0x1, {
            'Content-Transfer-Encoding': 'binary',
            'contentType': _0x417e90(0x194)
        }), _0x33085c[_0x417e90(0x17b)](_0x417e90(0x195), Buffer['from'](_0x19d377), {
            'filename': _0x417e90(0x18c),
            'contentType': 'image/jpeg'
        }), _0x33085c['submit']({
            'url': _0x3d731a,
            'host': _0x417e90(0x185),
            'path': '/' + _0x45d309,
            'protocol': _0x417e90(0x191),
            'headers': {
                'User-Agent': 'okhttp/4.9.3',
                'Connection': _0x417e90(0x18d),
                'Accept-Encoding': 'gzip'
            }
        }, function (_0x5b32c5, _0x5dadb6) {
            const _0x5658dc = _0x417e90;
            _0x5b32c5 && _0x528f23();
            let _0x187e4f = [];
            _0x5dadb6['on'](_0x5658dc(0x186), function (_0x329c05, _0x59bb97) {
                const _0x39c0c2 = _0x5658dc;
                _0x187e4f[_0x39c0c2(0x17a)](_0x329c05);
            })['on'](_0x5658dc(0x17e), () => {
                const _0x450e9b = _0x5658dc;
                _0x42ad59(Buffer[_0x450e9b(0x196)](_0x187e4f));
            }), _0x5dadb6['on'](_0x5658dc(0x183), _0x4e1644 => {
                _0x528f23();
            });
        });
    });
}
module[giftedtech_0x14efe8(0x17f)][giftedtech_0x14efe8(0x192)] = remini;
function giftedtech_0x3bab() {
    const _0x28ec77 = [
        '311859AsDfbI',
        'push',
        'append',
        '1414LPcuwG',
        '110NXbcqD',
        'end',
        'exports',
        '8888136PkcXBj',
        'https://inferenceengine.vyro.ai/',
        '8527716XxIVxZ',
        'error',
        'form-data',
        'inferenceengine.vyro.ai',
        'data',
        'enhance',
        '105VlObWk',
        '2429355ponUlu',
        'includes',
        '1tpdpMC',
        'enhance_image_body.jpg',
        'Keep-Alive',
        '9178337AedvdC',
        '218692dJwKGa',
        'recolor',
        'https:',
        'remini',
        'dehaze',
        'multipart/form-data;\x20charset=uttf-8',
        'image',
        'concat'
    ];
    giftedtech_0x3bab = function () {
        return _0x28ec77;
    };
    return giftedtech_0x3bab();
}