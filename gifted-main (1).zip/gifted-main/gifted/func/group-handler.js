function giftedtech_0x46c9(_0x27a473, _0x38d308) {
    const _0x53d98e = giftedtech_0x53d9();
    return giftedtech_0x46c9 = function (_0x46c923, _0xd48f1f) {
        _0x46c923 = _0x46c923 - 0x9f;
        let _0x38c292 = _0x53d98e[_0x46c923];
        return _0x38c292;
    }, giftedtech_0x46c9(_0x27a473, _0x38d308);
}
(function (_0x13599a, _0x38b741) {
    const _0x5d4626 = giftedtech_0x46c9, _0x41e6b5 = _0x13599a();
    while (!![]) {
        try {
            const _0x20a744 = -parseInt(_0x5d4626(0xb9)) / 0x1 * (parseInt(_0x5d4626(0xa6)) / 0x2) + parseInt(_0x5d4626(0xb1)) / 0x3 * (-parseInt(_0x5d4626(0xa9)) / 0x4) + parseInt(_0x5d4626(0xab)) / 0x5 * (-parseInt(_0x5d4626(0xad)) / 0x6) + parseInt(_0x5d4626(0xbb)) / 0x7 + parseInt(_0x5d4626(0xc0)) / 0x8 + -parseInt(_0x5d4626(0xa0)) / 0x9 + parseInt(_0x5d4626(0xb2)) / 0xa * (parseInt(_0x5d4626(0xbd)) / 0xb);
            if (_0x20a744 === _0x38b741)
                break;
            else
                _0x41e6b5['push'](_0x41e6b5['shift']());
        } catch (_0x3a6478) {
            _0x41e6b5['push'](_0x41e6b5['shift']());
        }
    }
}(giftedtech_0x53d9, 0x5b09a));
import giftedtech_0xd0792f from 'moment-timezone';
import giftedtech_0x1c16ab from '../../set.cjs';
function giftedtech_0x53d9() {
    const _0x427379 = [
        '1225290djtpoE',
        'DD/MM/YYYY',
        'HH:mm:ss',
        '715952RtVnoW',
        'groupMetadata',
        '983349GcrVbb',
        '>\x20Goodbye\x20@',
        'https://lh3.googleusercontent.com/proxy/esjjzRYoXlhgNYXqU8Gf_3lu6V-eONTnymkLzdwQ6F6z0MWAqIwIpqgq_lk4caRIZF_0Uqb5U8NWNrJcaeTuCjp7xZlpL48JDx-qzAXSTh00AVVqBoT7MJ0259pik9mnQ1LldFLfHZUGDGY=w1200-h630-p-k-no-nu',
        'image',
        'th\x20member.\x0a>\x20Joined\x20at:\x20',
        'format',
        '6faBUPY',
        'remove',
        'Leave',
        '263820CQOBgo',
        '>\x20Hello\x20@',
        '3340420FjewgL',
        'participants',
        '6yTdeHI',
        '!\x20Welcome\x20to\x20*',
        'subject',
        'Africa/Nairobi',
        '12XdXMLF',
        '140iMfZRI',
        'WELCOME',
        'https://giftedtech.my.id',
        '*.\x0a>\x20You\x20are\x20the\x20',
        'split',
        'length',
        '\x20in\x20the\x20group.\x0a>\x20Left\x20at:\x20',
        '242221CQKlZo',
        '\x20from\x20',
        '3442348bkREnp',
        '\x20on\x20'
    ];
    giftedtech_0x53d9 = function () {
        return _0x427379;
    };
    return giftedtech_0x53d9();
}
export default async function GroupParticipants(_0x4a9c1d, {
    id: _0x20cd62,
    participants: _0x1ac195,
    action: _0x307405
}) {
    const _0xf7cc78 = giftedtech_0x46c9;
    try {
        const _0x1f06d4 = await _0x4a9c1d[_0xf7cc78(0x9f)](_0x20cd62);
        for (const _0xce032f of _0x1ac195) {
            let _0x2be414;
            try {
                _0x2be414 = await _0x4a9c1d['profilePictureUrl'](_0xce032f, _0xf7cc78(0xa3));
            } catch {
                _0x2be414 = _0xf7cc78(0xa2);
            }
            if (_0x307405 == 'add' && giftedtech_0x1c16ab[_0xf7cc78(0xb3)]) {
                const _0x2ef940 = _0xce032f[_0xf7cc78(0xb6)]('@')[0x0], _0x5ceced = giftedtech_0xd0792f['tz']('Africa/Nairobi')[_0xf7cc78(0xa5)](_0xf7cc78(0xbf)), _0xf9361e = giftedtech_0xd0792f['tz'](_0xf7cc78(0xb0))[_0xf7cc78(0xa5)]('DD/MM/YYYY'), _0x224808 = _0x1f06d4[_0xf7cc78(0xac)][_0xf7cc78(0xb7)];
                _0x4a9c1d['sendMessage'](_0x20cd62, {
                    'text': _0xf7cc78(0xaa) + _0x2ef940 + _0xf7cc78(0xae) + _0x1f06d4[_0xf7cc78(0xaf)] + _0xf7cc78(0xb5) + _0x224808 + _0xf7cc78(0xa4) + _0x5ceced + _0xf7cc78(0xbc) + _0xf9361e + '\x0a\x22',
                    'contextInfo': {
                        'mentionedJid': [_0xce032f],
                        'externalAdReply': {
                            'title': 'Welcome',
                            'mediaType': 0x1,
                            'previewType': 0x0,
                            'renderLargerThumbnail': !![],
                            'thumbnailUrl': _0x1f06d4[_0xf7cc78(0xaf)],
                            'sourceUrl': _0xf7cc78(0xb4)
                        }
                    }
                });
            } else {
                if (_0x307405 == _0xf7cc78(0xa7) && giftedtech_0x1c16ab[_0xf7cc78(0xb3)]) {
                    const _0x42f08e = _0xce032f[_0xf7cc78(0xb6)]('@')[0x0], _0x1499b6 = giftedtech_0xd0792f['tz'](_0xf7cc78(0xb0))[_0xf7cc78(0xa5)](_0xf7cc78(0xbf)), _0x5e2e72 = giftedtech_0xd0792f['tz']('Africa/Nairobi')['format'](_0xf7cc78(0xbe)), _0x25ffe5 = _0x1f06d4[_0xf7cc78(0xac)][_0xf7cc78(0xb7)];
                    _0x4a9c1d['sendMessage'](_0x20cd62, {
                        'text': _0xf7cc78(0xa1) + _0x42f08e + _0xf7cc78(0xba) + _0x1f06d4[_0xf7cc78(0xaf)] + '.\x0a>\x20We\x20are\x20now\x20' + _0x25ffe5 + _0xf7cc78(0xb8) + _0x1499b6 + '\x20on\x20' + _0x5e2e72 + '\x22',
                        'contextInfo': {
                            'mentionedJid': [_0xce032f],
                            'externalAdReply': {
                                'title': _0xf7cc78(0xa8),
                                'mediaType': 0x1,
                                'previewType': 0x0,
                                'renderLargerThumbnail': !![],
                                'thumbnailUrl': _0x2be414,
                                'sourceUrl': _0xf7cc78(0xb4)
                            }
                        }
                    });
                }
            }
        }
    } catch (_0x46df22) {
        throw _0x46df22;
    }
}